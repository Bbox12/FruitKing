<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://mypostman.in');
        require_once 'DB_Connect.php';
  
        $db = new Db_Connect();
        $conn = $db->connect();

 
if(!$conn){
   echo "Could not connect to DBMS"; 
    }else { 




try{

      
  $response = array();


   $result =$conn->query("SELECT ID FROM `foods` ORDER BY ID DESC LIMIT 1");

   if ($result->num_rows == 0) {
    $jsonRow_201=array(
               "ID"=>1001,
             );


array_push($response, $jsonRow_201);
         }else{
            while ($user = mysqli_fetch_assoc($result)) {

$jsonRow_201=array(
               "ID"=>$user['ID']+1,
             );


array_push($response, $jsonRow_201);

}
         }
          


  

echo json_encode($response);
 


} catch(Error $e) {
    $trace = $e->getTrace();
    echo $e->getMessage().' in '.$e->getFile().' on line '.$e->getLine().' called from '.$trace[0]['file'].' on line '.$trace[0]['line'];
}



}
 
    
 
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>